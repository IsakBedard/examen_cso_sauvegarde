#!/bin/bash
echo "360" > /sys/class/gpio/export #bouton
echo "in" > /sys/class/gpio/gpio360/direction #bouton en input
echo "233" > /sys/class/gpio/export #vert
echo "out" > /sys/class/gpio/gpio233/direction #lumiere verte en output
echo "80" > /sys/class/gpio/export #rouge
echo "out" > /sys/class/gpio/gpio80/direction #lumiere rouge en output
echo "0" > /sys/class/gpio/gpio80/value
echo "0" > /sys/class/gpio/gpio233/value
echo "33" > /sys/class/gpio/export #bleu
echo "out" > /sys/class/gpio/gpio33/direction #lumiere bleue en output
echo "1" > /sys/class/gpio/gpio33/value #on allume la lumiere bleue au depart du script
while true
do
	etat=$(cat /sys/class/gpio/gpio360/value)
	vert=$(cat /sys/class/gpio/gpio233/value)
	rouge=$(cat /sys/class/gpio/gpio80/value)
	bleu=$(cat /sys/class/gpio/gpio33/value)
	if [ $etat -gt 0 ]
	then
		if [ $bleu  -gt 0 }
		then
			echo "0" > /sys/class/gpio/gpio33/value
			echo "1" > /sys/class/gpio/gpio233/value
		elif [ $vert -gt 0 ]
		then
			echo "0" > /sys/class/gpio/gpio233/value
			echo "1" > /sys/class/gpio/gpio80/value
		elif [ $rouge -gt 0 }
		then
			echo "0" > /sys/class/gpio/gpio80/value
			echo "1" > /sys/class/gpio/gpio33/value
		fi
	fi
done
